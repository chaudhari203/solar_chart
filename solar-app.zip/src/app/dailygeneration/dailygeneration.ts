
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxChartsModule } from '@swimlane/ngx-charts';

@Component({
  standalone: true,
  selector: 'app-dailygeneration',
  imports: [CommonModule, NgxChartsModule],
  templateUrl: './dailygeneration.html',
  styleUrls: ['./dailygeneration.css']
})
export class Dailygeneration implements OnInit {

  dailydata = [
    { date: '2025-08-01', energy_kWh: 124.5 },
    { date: '2025-08-02', energy_kWh: 138.2 },
    { date: '2025-08-03', energy_kWh: 140.2 },
    { date: '2025-08-04', energy_kWh: 165.5 },
    { date: '2025-08-05', energy_kWh: 170.0 },
  ];

  chartData: any[]= [];

  
view: [number,number] = [500, 400];
  showXAxis = true;
  showYAxis = true;
  gradient = true;
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = 'Date';
  showYAxisLabel = true;
  yAxisLabel = 'Energy(KWH)';
  timeline = true;
  doughnut = true;
  showLabels = true;

  constructor(){}
  ngOnInit() {
    this.chartData = this.dailydata.map(item => ({
      name: item.date,
      value: item.energy_kWh
    }));

  }
}



